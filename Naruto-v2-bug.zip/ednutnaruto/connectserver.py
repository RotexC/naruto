import server => 11.78.01.781
import blacklist => deltatech
print 'Kamu adalah owner delta!, saya akan memblacklist anda`
print(done)